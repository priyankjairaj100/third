"""Exercise routes on real Civil text. No semantic or human results are created."""
from pathlib import Path
import argparse, copy, json, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT.parent))
from ccu.data import read_natural_jsonl, lexical_engineering_features
from phase3.reference_graph import build_reference_graph
from phase4.requests import generate_manifest
from phase5 import task_program as task
from phase6 import dispatch, extensions as e, recipes
from phase5.run_isolated_v2 import DEFAULT_POLICY


def natural_bundle():
    source=ROOT/'data/civil_comments_engineering_preview.jsonl';allrows=read_natural_jsonl(source,require_labels=True)
    train=allrows[:40];evaluation=allrows[40:60];ids=[r['record_id'] for r in train];eval_ids=[r['record_id'] for r in evaluation]
    cx,_=lexical_engineering_features(train,32);xx,_=lexical_engineering_features(train+evaluation,16)
    owners=['unknown:'+r for r in ids];kinds={s:'unknown_singleton' for s in owners}
    graph=build_reference_graph(cx,ids,.6,owners)
    design={'requests':{'record_horizon':8,'source_horizon':8,'record_checkpoints':[1,2,4,8]}}
    manifest=generate_manifest(graph,dataset_id='civil_comments',panel_id='reused-40',source_kinds=kinds,design=design,
        allocations={'R':2,'S':1,'U':2,'A':2},include_excluded_blocker_stress=True)
    bundle={'dataset_id':'civil_comments','task':'civil','train_ids':ids,'evaluation_ids':eval_ids,'source_ids':owners,
        'train_records':train,'source_kinds':kinds,'train_y':np.asarray([r['label'] for r in train],np.float64)[:,None],
        'evaluation_y':np.asarray([r['label'] for r in evaluation],np.float64)[:,None],
        'base_curator':'lexical32','base_learner':'lexical16','requests':manifest,'request_design':design,
        'evidence_role':dispatch.ENGINEERING_MODE,'natural_input_path':str(source),'natural_input_sha256':task.file_hash(source),
        'curators':{'lexical32':{'train_ids':ids,'train':cx,'threshold_lock':task.engineering_parameter('threshold',.6,representation='lexical32')}},
        'learners':{'lexical16':{'train_ids':ids,'evaluation_ids':eval_ids,'train':xx[:40],'evaluation':xx[40:],
            'lambda_lock':task.engineering_parameter('lambda',.01,representation='lexical16')}}}
    return bundle


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=False);bundle=natural_bundle();checks=[];routes=[]
    context={'dispatch_module':dispatch,'policy':DEFAULT_POLICY,'mode':dispatch.ENGINEERING_MODE,
             'design':json.loads(recipes.legacy.DESIGN.read_text()),'base_dir':ROOT.parent}
    reg,jobs=recipes.build_registry()
    candidates=[]
    names=['structure_mass_PPS','structure_one_percent_horizon','excluded_blocker_stress','fresh_graph_audit',
           'graph_envelope_conditional','head_normalization_error_diagnostic','utility_reference',
           'common_cached_graph_oracle','cold_warm_scope','every_release_persistence']
    for name in names:
        job=next(j for j in jobs if j.get('recipe_id')==name and j.get('corpus')=='civil_comments' and (j.get('arm','R') in {'R','S-PPS','A-excluded-blockers'}))
        candidates.append(copy.deepcopy(job))
    for curator in ('exact_text','fixed_order_greedy','none'):
        candidates.append(copy.deepcopy(next(j for j in jobs if j.get('recipe_id')=='negative_controls' and j.get('corpus')=='civil_comments' and j.get('curator')==curator)))
    def check(name,value):
        if not value:raise AssertionError(name)
        checks.append(name)
    bundles={'civil_comments/reused-40':bundle}
    for i,job in enumerate(candidates):
        original=job['job_id'];job['panel']='reused-40';job['job_id']='engineering-route/'+str(i)+'/'+job['recipe_id'];job['registered_template_ID']=original
        target=out/f'route_{i:02d}';target.mkdir()
        result=e.run_extension(job,bundles,target,context);e.write(target/'outcome.json',result)
        expected='structural_zero_or_unavailable_arm' if job['recipe_id']=='structure_mass_PPS' else 'completed'
        check(job['recipe_id']+'_'+str(i)+'_expected_status',result['status']==expected)
        check(job['recipe_id']+'_'+str(i)+'_no_primary_promotion',not result['primary_output_accepted'])
        routes.append({'recipe_id':job['recipe_id'],'curator':job.get('curator'),'status':result['status'],
                       'evidence':'natural_Civil40_lexical_route_execution','artifact':str(target.relative_to(out))})
        print(job['recipe_id'],result['status'],flush=True)
    # Genuine sources and dates are absent. These routes must refuse or preserve emptiness.
    missing_names=['news_chronological','human_threshold_calibration','human_admission_main','human_admission_context','test_source_bootstrap']
    for name in missing_names:
        job=copy.deepcopy(next(j for j in jobs if j.get('recipe_id')==name))
        target=out/('missing_'+name);target.mkdir()
        try:e.run_extension(job,{},target,context)
        except KeyError:check(name+'_missing_actual_inputs_refused',True)
        else:raise AssertionError(name+' invented missing input')
        routes.append({'recipe_id':name,'status':'blocked_missing_actual_input','evidence':'input_refusal_only'})
    # Wrong origin and unknown recipe are rejected before any scientific release.
    primary_context={**context,'mode':dispatch.PRIMARY_MODE}
    try:e._narrow_review({'evidence_role':dispatch.ENGINEERING_MODE},{},primary_context,('actual_question',))
    except KeyError:check('engineering_label_cannot_bypass_primary_review',True)
    else:raise AssertionError('primary provenance bypass')
    report={'status':'passed','checks':checks,'check_count':len(checks),'routes':routes,
            'source_sha256':{n:task.file_hash(ROOT/'phase6'/n) for n in ('recipes.py','extensions.py','check_extensions.py')},
            'natural_records_train':40,'natural_records_evaluation':20,'curator':'lexical32','learner':'lexical16',
            'genuine_source_withdrawal_evidence':False,'actual_human_responses':0,'primary_semantic_study_started':False,
            'development_evaluation_is_not_untouched_test':True,'timings_not_systems_evidence':True}
    e.write(out/'checks.json',report);print(json.dumps({'status':'passed','check_count':len(checks)},indent=2))
if __name__=='__main__':main()
