ANONYMOUS TMLR SUPPLEMENT V6

This version binds the four literature-only manuscript replacements to unchanged
V5/V4 scientific code and aggregate evidence. COMPARISON.txt and COMPARISON.json
give supported contrasts and unresolved full-text requirements. Both complete
prior texts remain unavailable; no novelty clearance is asserted.

Extract to an empty directory. Run python3 -B /path/to/check_all.py using Python
3.10+ without -O; keep outputs outside the extraction. It verifies file inventory,
hashes, exact source delta and nested historical evidence. It does not compile,
fetch sources or execute private scientific inference/training. For code, extract
evidence_v5.zip then its nested archives and follow their READMEs.

Prior calibration failures, absent human review, blocked original study and
limits on state/membership checks remain unchanged. Private corpus, identifiers,
labels, vectors, states, scheduler logs, author forms and author-reference PDF
are excluded. Hashes establish integrity, not authenticity or unlinkability.
No full-paper review, new scientific experiment, author attestation, scheduler
restart or actual submission is certified by this package.
