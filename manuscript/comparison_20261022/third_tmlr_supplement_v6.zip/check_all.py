#!/usr/bin/env python3
"""Validate the exact literature update and unchanged nested evidence."""
from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, sys, tempfile, zipfile
if sys.version_info < (3, 10) or not __debug__:
    raise SystemExit('Use Python 3.10+ without -O.')
root = Path(__file__).resolve().parent
manifest = json.loads((root/'MANIFEST.json').read_text())
assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == set(manifest['files']) | {'MANIFEST.json'}
for name, expected in manifest['files'].items():
    data = (root/name).read_bytes()
    assert len(data) == expected['bytes']
    assert hashlib.sha256(data).hexdigest() == expected['sha256'], name
delta = json.loads((root/'SOURCE_CHANGE.json').read_text())
data = (root/'manuscript.tex').read_bytes()
assert hashlib.sha256(data).hexdigest() == delta['source_after_sha256']
text = data.decode()
for change in reversed(delta['changes']):
    assert text.count(change['new']) == 1
    text = text.replace(change['new'], change['old'], 1)
assert hashlib.sha256(text.encode()).hexdigest() == delta['source_before_sha256']
with tempfile.TemporaryDirectory(prefix='third-v5-evidence-') as td:
    with zipfile.ZipFile(root/'evidence_v5.zip') as z:
        assert z.testzip() is None
        for info in z.infolist():
            p = PurePosixPath(info.filename)
            assert not p.is_absolute() and '..' not in p.parts
            assert ((info.external_attr >> 16) & 0o170000) != 0o120000
        z.extractall(td)
    assert (Path(td)/'manuscript.tex').read_bytes() == text.encode()
    run = subprocess.run([sys.executable, '-B', str(Path(td)/'check_all.py')], cwd=td, capture_output=True, text=True)
    assert run.returncode == 0, run.stdout + run.stderr
print(json.dumps({'passed': True, 'exact_four_literature_replacements_verified': True,
                  'unchanged_v5_nested_replay_passed': True,
                  'private_scientific_inputs_recomputed': False,
                  'full_text_comparisons_complete': False}, indent=2))
