ANONYMOUS CODE AND AGGREGATE SUPPLEMENT, VERSION 1

Scope
-----
This supplement accompanies a theory and negative-calibration manuscript.
It contains six unmodified algorithm/source files, source-derived anonymous
aggregates, a transformation ledger, a file manifest and an aggregate checker.
It contains no manuscript, historical archive, reviews, source text corpus,
private pair/record IDs, individual labels, model outputs, weights or human forms.
No human annotation or review is introduced. Historical unmet human gates stay
unmet. No threshold, fresh validation, development effect or held-out result is
created by this package.

Quick replay
------------
Extract the ZIP into a new empty directory. From its top-level directory run:

    python3 -B check_aggregates.py

Python 3.10 or later is required for this standard-library-only checker. It
writes JSON to stdout and does not change the files. It checks the complete
manifest, source syntax, all 102 published v3/v4 cut quotients and decisions,
category margins, v4 cross-counts and 12 bin-boundary reconstructions, and all
72 historical compute rows. It prints the two-row calibration summary table.

The checker does not recompute cuts from private pair scores/labels. At thresholds
inside a sampling bin, the aggregate ledger supplies the weighted numerator and
denominator; only their quotient, nesting and gate decision are checked. At the
12 v4 bin boundaries the included bin counts support full aggregate reconstruction.
The sensitivity maximum is favorable missing/uncertain imputation, not a confidence
bound. The raw 27/360 count is a stratified-sample count, not population prevalence.
Agreement of two LLMs is not human validity or ground truth.

Code
----
code/algorithm_round2.py is the exact integer coefficient-repair implementation
and its existing mathematical software-fixture harness. It has no nonstandard
Python dependencies. Running its existing main program writes a report; use an
output path outside this sealed package. These small constructed fixtures are
software checks, not natural empirical evidence, and cannot prove theorems.

code/empirical_execution/phase10/finite_word_codec.py is the exact canonical
finite-sign family codec. The accompanying phase3/reference_graph.py,
phase3/panels.py, ccu/core.py and ccu/__init__.py provide its unchanged import
closure. These modules require NumPy and SciPy. Historical project versions were
Python 3.12.14, NumPy 2.3.5 and SciPy 1.17.0. The aggregate checker needs none of
them, and this supplement does not claim to recreate that historical runtime.

The codec is a service for the stated constructed family, not a general corpus
compressor. mD counts private sign information only. Public construction data,
deletions, padding, outputs and workspace remain separate. The exact head is
rational; no arbitrary floating solver receives a new accuracy certificate.
These six files are not the full Phase 5/6 empirical service or all baselines.
No full empirical or historical theorem-test-suite replay is claimed.

Provenance and anonymous review
-------------------------------
MANIFEST.json hashes every payload file. Its own hash and the archive hash are
kept in the separate delivery record. TRANSFORMATIONS.json records exact source
hashes, original aggregate-report hashes, retained fields and omissions.
Original code bytes are unmodified. Aggregate records retain their numbers;
only an explicit allowlist is published. Compute job identifiers are replaced
by ordinal positions which have no scheduling meaning. No original receipt is
included. The private builder and the mapping to original paths are excluded.

Hashes support byte binding; they do not authenticate absent private data.
Exact source hashes can be externally linkable and do not promise anonymity
against source matching. No account, cluster host, original repository URL or
absolute local path is intentionally present. Bibliographic authors in any source
comments would remain ordinary third-party attribution, not be anonymized.

Verification limits
-------------------
The package checks aggregate arithmetic and integrity. This is not fresh model
inference, full empirical replay, semantic validation, universal theorem proof,
new independent scientific verification, or a submission-readiness certificate.
Compute totals are an incomplete historical subset; parallel durations overlap.
Requested CPU time is not utilization or billing. No energy or monetary estimate
is supplied. The original calibration failures and failed engineering jobs remain
visible and do not authorize retuning or downstream effects.
