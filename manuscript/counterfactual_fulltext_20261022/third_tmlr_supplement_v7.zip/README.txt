ANONYMOUS TMLR SUPPLEMENT V7 — SUPPLIED FULL-TEXT COMPARISON

The six-page Tadakamalla et al. manuscript has now been read in full. Its exact
threshold-family result and joint-success counting proof are compared with our
fixed-feature curation/ridge and remaining-horizon state contract. Read
COMPARISON.txt for the quantifier caveat and page-specific evidence. Dominici's
thesis remains unavailable; no general novelty or superiority clearance follows.

SOURCE_CHANGE.json contains exactly two literature/status replacements from V6.
Scientific theorems, experiment results, negative gates and protocols are unchanged.
The supplied third-party PDF and its extracted text are not redistributed here.
Its hash binds which version was inspected. Historical V6 statements about missing
texts describe the earlier access state; this top-level comparison supersedes them.

Extract into an empty directory and run python3 -B check_all.py with Python3.10+
without -O. Keep outputs outside extraction. The standard-library checker checks
inventory/hashes, reverses the exact delta and runs unchanged V6 evidence replay.
It does not fetch sources, compile TeX or rerun private scientific computation.
Nested historical archives retain their own README and source bindings.

No private corpus, source IDs, model labels, vectors, author forms or scheduler
logs are included. Integrity hashes do not guarantee authenticity or unlinkability.
Author declarations/profile IDs remain pending. Scheduler remains paused by user.
No actual submission, new experiment, author contact or scientific gate change.
