ANONYMOUS TMLR SUPPLEMENT V5

This wrapper binds the current manuscript to the unchanged V4 code and aggregate
evidence. The only manuscript change from the reviewed V4 source is a first-page
AI-assistance footnote required by the TMLR FAQ. SOURCE_CHANGE.json reconstructs
the exact prior source; historical reviews are not reissued for new science.

Extract this ZIP into an empty directory, then run from any directory:
    python3 -B /path/to/extracted/check_all.py
Use Python 3.10+ and the standard library, without -O. Save outputs outside the
extracted directory. The checker verifies exact inventory and hashes, the exact
manuscript delta, and the unchanged V4 checker in temporary storage. V4 recursively
replays the natural-development structural/repair and negative-calibration
aggregate evidence and syntax-checks included research code. It neither fetches
resources nor executes private inference, graph construction, or training.

For code inspection, extract evidence_v4.zip separately and read its README.txt.
manuscript.tex embeds the official TMLR style and bibliography; compiling it needs
a compatible TeX environment and packages. The portable checker does not compile.

Both LLM calibrations remain negative. No threshold, human annotation, learner
comparison, held-out evaluation, utility or comparative cost benefit is claimed.
Membership/logical-state receipts do not prove graph-byte equality, physical
erasure or kernel-enforced no-reaccess. Private text, labels, IDs, vectors, states,
model weights, actual scheduler receipts and author metadata are not included.

Hash checks establish integrity, not authenticity. Exact code and hashes may be
linkable to public development history; this is not an unlinkability guarantee.
Two cited full texts remain unavailable; the paper acknowledges their relevance
without priority, exclusion or superiority claims. Submission eligibility and
author declarations are outside this technical package. No submission occurred.
