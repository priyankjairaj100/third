#!/usr/bin/env python3
"""Verify the submission wrapper and replay unchanged historical evidence."""
from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, sys, tempfile, zipfile
if sys.version_info < (3, 10) or not __debug__:
    raise SystemExit('Use Python 3.10+ without -O.')
root = Path(__file__).resolve().parent
manifest = json.loads((root/'MANIFEST.json').read_text())
actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
assert actual == set(manifest['files']) | {'MANIFEST.json'}, 'File inventory differs'
for name, expected in manifest['files'].items():
    data = (root/name).read_bytes()
    assert len(data) == expected['bytes']
    assert hashlib.sha256(data).hexdigest() == expected['sha256'], name
delta = json.loads((root/'SOURCE_CHANGE.json').read_text())
data = (root/'manuscript.tex').read_bytes()
assert hashlib.sha256(data).hexdigest() == delta['source_after_sha256']
text = data.decode()
assert text.count(delta['new']) == 1
old = text.replace(delta['new'], delta['old'], 1).encode()
assert hashlib.sha256(old).hexdigest() == delta['source_before_sha256']
with tempfile.TemporaryDirectory(prefix='third-evidence-') as tmp:
    with zipfile.ZipFile(root/'evidence_v4.zip') as z:
        assert z.testzip() is None
        for info in z.infolist():
            p = PurePosixPath(info.filename)
            assert not p.is_absolute() and '..' not in p.parts
            assert not ((info.external_attr >> 16) & 0o170000) == 0o120000
        z.extractall(tmp)
    result = subprocess.run([sys.executable, '-B', str(Path(tmp)/'check_all.py')],
                            cwd=tmp, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr + result.stdout
print(json.dumps({'passed': True, 'source_change': 'first-page assistance footnote only',
                  'unchanged_v4_nested_replay_passed': True,
                  'private_scientific_inputs_recomputed': False,
                  'author_declarations_verified': False}, indent=2))
