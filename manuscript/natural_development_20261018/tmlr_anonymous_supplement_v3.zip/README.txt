ANONYMOUS SUPPLEMENT, VERSION 3

Scope
-----
This version accompanies the exact manuscript source hash in BINDINGS.json.
It adds only the completed natural-development structural characterization
(Stage 1) to the historical theory/negative-calibration supplement. Stage 2
outputs are absent. This is not a full project archive or a submission-ready
certificate. The manuscript itself is not included.

The two original LLM calibrations failed. No semantic threshold was selected,
no fresh model validation was admitted, and the original semantic-effect study
remains incomplete. Stage 1 preserves all 51 original score cutoffs on a fixed
1,001-row development-training panel. It is a post-failure structural study,
not a repaired calibration or evidence of semantic quality or task benefit.
Stage 1 used no annotations. Future annotation remains fully LLM with zero
human pair review; original unmet human gates remain unmet.

Replay
------
Extract the ZIP into a new empty directory. From any directory run:

    python3 -B /path/to/extracted/check_all.py

Use Python 3.10 or newer without -O. The checker uses only the standard library,
needs no network or private data, and prints JSON to stdout. Save receipts
outside the extracted directory because its inventory is intentionally exact.
The checker verifies every payload hash, replays structure/replay_aggregates.py,
syntax-checks five generating/dependency source files without importing them,
and extracts the historical ZIP into a temporary directory to run its unchanged
checker. The temporary extraction is removed automatically.

The historical checker verifies 102 calibration-cut quotients/decisions,
12 reconstructible v4 bin boundaries, and 72 deidentified compute records.
The Stage 1 checker verifies 51 cut records, 204 exact expected-admission
fractions, 50,050 blocker-CDF comparisons, and 53 completion-bound outputs.
These are aggregate arithmetic and integrity checks. They do not regenerate
embeddings, graphs, private observations, labels or LLM outputs, and do not
prove theorems or establish authenticity of unavailable source artifacts.

Contents
--------
historical/tmlr_anonymous_supplement_v1.zip is byte-identical to the previously
reviewed anonymous supplement. Its old scope text and reviews are unchanged.
structure/ is the complete, byte-identical 63-file public Stage 1 bundle,
including its independent aggregate review and its own sealed inventory.
check_all.py, BINDINGS.json, PRIVACY.json and MANIFEST.json provide this version's
portable wrapper, source bindings, disclosure and complete payload inventory.
No optional figure is needed to replay the complete numerical records.

Generating code for inspection
------------------------------
code/stage1/structure_stage1.py is the exact executed Stage 1 generator.
code/empirical_execution/ preserves the original relative layout of the four
frozen scorer/graph dependencies named in the executed plan. All five files
match their existing source hashes. check_all.py parses their Python syntax
without importing or executing them; their NumPy/SciPy imports are not needed
for the aggregate checker.

These sources make the scoring, panel checks, counting and bounded scalar
oracle inspectable. They do not make the private experiment independently
runnable from this ZIP. Raw vectors, allocations and record/source identities
are omitted, as are the operational launcher, job wrapper and original plan
with private dispatch settings. structure/study_protocol.json is a disclosed
deidentified scientific view, not a replacement executable protocol. The
observed generating runtime was Linux, Python 3.13.7, NumPy 2.5.3 and SciPy
1.17.1. No fresh graph construction or private-input execution is performed
or claimed by the public checker. No Stage 2 code or outputs are included.

Privacy and provenance
----------------------
The package omits operational scripts, actual host/user/job identifiers,
private filesystem paths, corpus text, record/source identifiers, per-pair
labels, feature vectors, raw execution logs, model weights and repository
history. The Stage 1 source-binding ledger retains names and hashes of omitted
operational components to preserve provenance; those components are not included.
The historical archive contains six public research code files, which are not
the complete experiment runtime. Exact code and hashes can be linked to public
sources, so removal of identifying metadata is not an unlinkability guarantee.

All old artifacts and reviews retain their original source bindings. This
wrapper does not silently bind a historical review to the current manuscript.
The manifest is an integrity inventory, not an external authenticity signature.
Numerical modules in the historical archive need NumPy/SciPy if separately run;
the supplied aggregate replay does not execute those modules.
