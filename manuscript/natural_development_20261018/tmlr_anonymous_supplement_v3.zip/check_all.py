#!/usr/bin/env python3
"""Verify the complete supplement inventory and replay both aggregate bundles.

Python 3.10+ standard library only. No network or private inputs are used.
Prints a receipt; temporary historical extraction is removed automatically.
"""
from pathlib import Path, PurePosixPath
import hashlib
import ast
import json
import stat
import subprocess
import sys
import tempfile
import zipfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result

    def constant(value):
        raise ValueError("Non-finite JSON value: " + value)

    return json.loads(path.read_bytes(), object_pairs_hook=pairs,
                      parse_constant=constant)


def binding(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def safe_name(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and ".." not in path.parts and "\\" not in name


def replay(script, cwd):
    result = subprocess.run([sys.executable, "-B", str(script)], cwd=cwd,
                            capture_output=True, text=True, timeout=120)
    require(result.returncode == 0, "Replay failed: " + result.stderr)
    receipt = json.loads(result.stdout)
    require(receipt.get("passed") is True, "Replay did not pass")
    return receipt


def main():
    require(sys.version_info >= (3, 10), "Python 3.10 or newer is required")
    require(not sys.flags.optimize, "Run without -O: nested checkers use assertions")
    root = Path(__file__).resolve().parent
    manifest = read_json(root / "MANIFEST.json")
    require(manifest["schema"] == "anonymous-supplement-inventory-v3", "Wrong inventory schema")
    require(not any(p.is_symlink() for p in root.rglob("*")), "Symbolic links are not permitted")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(actual == set(manifest["files"]) | {"MANIFEST.json"}, "Unexpected or missing file")
    for name, expected in manifest["files"].items():
        require(safe_name(name), "Unsafe inventory name")
        require(binding(root / name) == expected, "Hash or size mismatch: " + name)
    sources = read_json(root / "BINDINGS.json")
    require(sources["scope"] == "historical_calibration_and_completed_structure_stage1_only", "Unexpected scope")
    require(sources["original_semantic_gate_passed"] is False, "Original gate must remain failed")
    require(sources["stage2_outputs_included"] is False, "Stage 2 is outside this version")
    historical = root / "historical" / "tmlr_anonymous_supplement_v1.zip"
    require(binding(historical) == sources["historical_anonymous_supplement"], "Historical archive mismatch")
    require(binding(root / "structure" / "MANIFEST.json") == sources["structure_manifest"], "Stage 1 manifest mismatch")
    code = sources["generating_code"]
    require(len(code) == 5, "Expected five exact generating/dependency source files")
    stage_bindings = read_json(root / "structure" / "SOURCE_BINDINGS.json")
    require(code["code/stage1/structure_stage1.py"]["binding"] ==
            stage_bindings["executed_package_members"]["structure_stage1.py"], "Generator source binding mismatch")
    expected_code_names = {"code/stage1/structure_stage1.py"}
    for relative, expected in stage_bindings["frozen_research_sources"].items():
        name = "code/" + relative
        require(code[name]["binding"] == expected, "Frozen dependency binding mismatch")
        expected_code_names.add(name)
    require(set(code) == expected_code_names, "Generating-source inventory mismatch")
    for name, entry in code.items():
        require(safe_name(name), "Unsafe code name")
        require(binding(root / name) == entry["binding"], "Generating-source byte mismatch")
        ast.parse((root / name).read_text(), filename=name)
    structure_receipt = replay(root / "structure" / "replay_aggregates.py", root / "structure")
    with tempfile.TemporaryDirectory(prefix="anonymous-calibration-replay-") as directory:
        extracted = Path(directory)
        with zipfile.ZipFile(historical) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)), "Duplicate historical archive member")
            require(archive.testzip() is None, "Historical archive CRC failure")
            for member in archive.infolist():
                require(safe_name(member.filename), "Unsafe historical archive name")
                require(not stat.S_ISLNK(member.external_attr >> 16), "Historical archive symlink")
            archive.extractall(extracted)
        calibration_receipt = replay(extracted / "check_aggregates.py", extracted)
    require(structure_receipt["summary"]["threshold_selected"] is False, "No structural cutoff may be selected")
    require(structure_receipt["summary"]["human_or_model_annotations"] == 0, "Stage 1 adds no annotation")
    require(all(row["threshold_selected"] is False and row["fresh_validation"] is False
                for row in calibration_receipt["calibration_table"]), "Calibration failure changed")
    print(json.dumps({
        "passed": True,
        "payload_files_checked": len(manifest["files"]),
        "generating_source_files_syntax_checked": len(code),
        "generating_code_executed": False,
        "manuscript_source_sha256": sources["manuscript_source_sha256"],
        "historical_calibration": calibration_receipt,
        "structure_stage1": structure_receipt,
        "stage2_outputs_included": False,
        "original_semantic_gate_passed": False,
        "scope": "Inventory, byte identity and aggregate arithmetic only; no private-data, model or graph replay.",
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
