ANONYMOUS TMLR SUPPLEMENT
Unlearning What Was Never Trained: Exact Repair After Data Curation

Start here
Extract this ZIP into an empty directory. With Python 3.10 or newer run:

    python3 -B check_all.py

Do not use -O. Keep any redirected output outside this directory. No network,
GPU, NumPy or private data is required for this aggregate check. It verifies
the complete inventory, exact copied-source hashes, both negative calibration
decisions, historical compute totals, and structure/repair aggregate arithmetic.
It also checks the prompt/schema bindings and parses all Python source files.

What to read
manuscript.tex: one current manuscript source, including the official TMLR style.
annotation/: exact judge instructions and JSON schemas, with public protocol
settings for the two completed calibration versions. The judgment schema is
model-produced content; the response schema describes the surrounding harness
record. No example text, response or per-pair identifier is included.
code/algorithm_round2.py: exact integer coefficient-repair implementation.
code/empirical_execution/phase10/finite_word_codec.py: constructed-family codec.
code/stage1/: natural-development graph characterization generator.
code/stage2/: exact membership-repair generator and its bound helper.
evidence/calibration/: the two failed calibrations and compute aggregates.
evidence/structure/: all 51 structural cuts, protocol view and aggregate replay.
evidence/repair/: all 51 repair cuts, protocol view and aggregate replay.
SOURCE_MAP.json: source archive/member hashes for every unchanged copied file.
TMLR_STYLE_LICENSE.txt: license of the embedded official style.

Scientific scope
Both model-defined calibration versions failed. No threshold or fresh validation
was admitted. The original semantic-effect study and dependent held-out results
remain absent. The 1,001-row structural diagnostic and exact membership-repair
diagnostic are completed development checks, not semantic qualification or
comparative efficiency results. No human pair annotation or review is claimed.

Reproduction levels
The default command checks aggregate arithmetic and source identity. It does not
repeat private pair inference, reconstruct graphs or private states, reproduce
exact model tokens, or prove a theorem. Generating code is available for
inspection; private source text, allocations, record/source IDs, individual model
observations and feature vectors are intentionally excluded. These omissions
prevent independent end-to-end replication from this ZIP. Sampling-seed rules
are described, but the private activation locks are not distributed.

The integer algorithm has its original constructed software-fixture harness:

    python3 -B code/algorithm_round2.py --output /tmp/third_algorithm_check.json

This is an optional software check, not a new natural-data experiment or proof.
Run it only with an output path outside this sealed directory. Other generating
modules require NumPy/SciPy; their existing import layout is retained. The saved
natural diagnostics used Linux/Python 3.13.7/NumPy 2.5.3/SciPy 1.17.1; historical
theory modules used Python 3.12.14/NumPy 2.3.5/SciPy 1.17.0. These runtime facts
do not certify bitwise portability. The six original theory module copies and
all executed diagnostic sources are byte-identical to their bound predecessors.

Packaging and provenance
This package replaces recursive historical ZIP wrappers with direct access to
the unchanged evidence and code. Historical manuscript versions, correspondence,
development source deltas, author forms and third-party paper PDFs are excluded.
The completed diagnostic evidence retains its own original reviews and manifests;
those reviews are not rebound as reviews of this current manuscript. File hashes
establish integrity, not authenticity of unavailable private observations or
anonymity against external source matching. No empirical protocol, scientific
gate, model judgment or numerical result is changed by this repackaging.
