REPRODUCTION IMPLEMENTATION ADDENDUM

Purpose and limits

This directory discloses the preparation, encoding, development reservation,
calibration sampling, task rendering, constrained inference, and selection code
behind the reported workflow. Scientific implementation files are unchanged
copies with byte counts and SHA-256 bindings in ADDON_SOURCE_MAP.json. This is
implementation disclosure, not a claim that the private-data experiment can be
repeated from this anonymous archive alone. No new natural-data inference or
experiment was performed when constructing this addendum.

The public aggregate checker at supplement root remains the executable starting
point: python3 -B check_all.py. Its pass validates the included aggregate evidence
and its stated checks. It does not reproduce corpus extraction, embedding caches,
individual labels, or GPU execution. Hash matches establish artifact identity;
they do not independently validate the scientific contents of private artifacts.

Code layout and import use

code/ preserves the original package-relative paths. For scientific modules, put
both code/ and code/empirical_execution/ on PYTHONPATH. The phase3 and phase4
folders use Python namespace packages. Per-family local_run modules use sibling
imports such as protocol, contract, ledger, common, and bounded_reason. Import
or inspect each family in a fresh Python process with that family's directory on
sys.path; do not combine similarly named family modules in one interpreter.

The small local_run/llm_development_guard_v1_20261016/common.py is explicitly
DERIVED IMPORT SUPPORT, not a byte-identical copy of its original deployment
module. It contains the exact original require function plus a disclosure
comment. The unchanged panel_core.py only calls that helper. The mapping records
the original file hash, exact source lines, excerpt hash, and derived file hash.
Operational paths and unrelated deployment helpers are not distributed.

Implementation map

- empirical_execution/phase4/adapters.py: native XML parsing and Stack Exchange
  question extraction, owner identity handling, content normalization, tags,
  duplicate-link handling, source and time eligibility.
- empirical_execution/phase3/panels.py and run_preparation.py: account-source
  grouping, salted source partitioning, deterministic cross-split exact-copy and
  duplicate-link guards, and preparation orchestration.
- empirical_execution/phase4/model_selection.py: calibration-only top-tag
  vocabulary selection, ridge-selection implementation, and fixed evaluation
  helpers. Inclusion of helpers does not establish execution of every planned
  study or selection branch.
- empirical_execution/phase4/embeddings.py: complete content chunking, E5 query
  prefix, model loading, attention-masked mean pooling, content-token weighting,
  reference normalization, and fixed CPU execution recipe.
- local_run/llm_development_guard_v1_20261016/panel_core.py and
  RESERVATION_PLAN.json: whole-source reservation and deterministic development
  panel selection. The boundary source is retained whole.
- local_run/llm_selection_sampler_v1_20261014/sampler.py: original V3 all-pair
  score stream, 20-bin reservoir sampling, exact inclusion probabilities and
  weights, deterministic orientation, and randomized swap subset. Its deployment
  entry point still needs omitted pinned manifests, locks and input data.
- local_run/llm_annotation_statistics_v1_20261014/statistics_core.py: exact V3
  two-model weighted threshold selection and aggregate diagnostic calculations.
- local_run/model_annotation_v3_20261014/protocol.py and PLAN.json: original
  model-only protocol and negative-result interpretation.
- local_run/model_annotation_v4_20261014/sampling.py, protocol.py, PLAN.json and
  parent_PLAN.json: right-closed strata, fixed-size reservoir sampling, exact
  population-to-sample weights, joint two-model target, and frozen gate logic.
- local_run/model_annotation_runtime_v5_20261011/run_pilot.py and
  model_annotation_runtime_mistral_v1_20261011/run_pilot.py: exact family model
  loading and tokenize_call renderer functions reused by the production kernels.
  The user payload is JSON containing task_definition and documents A/B, within
  the pinned model's chat template. Only document text enters these task fields;
  annotation identifiers, similarity scores, stratum and threshold are omitted.
- Each corresponding bounded_reason.py: strict structured-output prefix guard,
  bounded reason, native greedy token decision, and completion handling.
- local_run/llm_annotation_inference_v1_20261014/ and
  local_run/llm_v4_inference_v2_20261014/: exact production contract, kernel and
  ledger implementation. V4 statistics_core.py contains the current model-only
  weighted selection calculation and finite-population boundary replay.

Historical names and preserved gates

run_pilot.py is a historical filename. Its renderer/loader/decoder functions were
reused by production inference; its old standalone pilot CLI is not the v3/v4
production experiment. Full deployment CLIs retain strict private-input,
historical package, runtime and activation checks. They intentionally do not
become runnable end to end merely by extracting this anonymous subset. Do not
remove the checks to make them pass.

empirical_execution/phase3/calibration.py is a legacy three-rater module included
because the reusable numerical score/bound helpers depend on it. Its historical
human-annotation collectors/evaluator do not define the current study. Current
annotation is fully LLM with zero human review. The v3/v4 protocol and V4
statistics_core.py define the current two-model agreement target; their failed
gates remain failed. Model agreement is not human semantic validity.

empirical_execution/config/planned_study_design.json preserves the original
broader design and preparation configuration, including original unmet gates.
Its historical venue, human-gate and planned-experiment text is not an execution
claim or current submission policy. The current manuscript and protocol view
identify the executed scope and retained negative results. The exact prompt and
schema copies under their original paths support dependency inspection; the
annotation/ copies at supplement root provide the same readable task material.

E5 recipe

REPRODUCTION_RECIPE.json is a source-bound explanatory view, not a new execution
record. embeddings.py tokenizes all content once without truncation, divides it
into consecutive chunks of at most 256 content tokens, and separately prepends
query-prefix tokens to every chunk. There is no content decode/retokenize step.
The model attends to content, prefix and special tokens; padding is excluded by
the attention mask. Chunks are processed in within-document batches of at most
eight. Attention-masked mean chunk vectors are normalized with coordinate-ordered
FP64 L2. Document pooling sums these vectors in content order weighted by each
chunk's content-token count, divides by total content tokens, normalizes in FP64,
and stores float32. This custom long-document aggregation is not a claim to use
a single-window default E5 recipe.

Observed runtime pins and dependencies

The authoritative versions are retained in each expectations.json,
runtime_plan.json and requirements.txt. They are historical observed/admitted
pins, not instructions to upgrade an environment. No installation or model
asset download is performed by the aggregate checker.

The fixed E5 cache recipe records Linux Python 3.13.7, NumPy 2.5.3, PyTorch
2.14.1+cpu, Transformers 4.57.6, tokenizers 0.22.2 and safetensors 0.8.0. It uses
CPU FP32 eager attention, eval mode, one intra-op and inter-op thread,
deterministic algorithms, seed zero, and MKLDNN disabled. Padding is fixed at
261 token positions; the admitted model capacity is 512. The adapters also use
idna, and preparation/scoring helpers use NumPy.

The production judge expectations record Python 3.13.7, PyTorch 2.11.0+cu128,
Transformers 4.57.6, tokenizers 0.22.2, lm-format-enforcer 0.11.3 and NumPy 2.5.3.
The admitted GPU family was A100 80GB, with BF16 and the pinned single-device
attention/runtime constraints. Both model IDs, revisions, tokenizer identities,
asset hashes and complete relevant runtime pins appear in the included
expectations and runtime plans. These assets are not redistributed.

Inputs and deployment pieces intentionally absent

The following are needed to repeat the original private calls and are not in the
anonymous supplement: native forum XML/text and ownership metadata; complete
prepared rows and embedding caches; original activation seed material and exact
sample pair allocations; individual model responses and token traces; request
bundles; model weights/tokenizer assets; cluster activation contracts and Slurm
receipts. Hash-only manifests are provenance evidence, not substitutes for these
inputs. Some original validation routines also require omitted historical
package manifests and prior terminal acceptance artifacts. No cluster launcher,
credential, private text, raw author/row ID or individual annotation was added.

The scientific functions and exact inference kernels can be inspected or reused
with separately acquired legitimate inputs and a suitable runtime. The supplied
aggregate evidence is the reproducible scope of check_all.py. Recreating the
private natural corpus, its sample realization and GPU judgments remains outside
what this release alone can establish.
