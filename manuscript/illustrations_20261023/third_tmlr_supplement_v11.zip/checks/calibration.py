#!/usr/bin/env python3
"""Read-only aggregate arithmetic and manifest replay, using only the standard library.

This does not rerun models, access raw observations, validate semantics, prove
universal theorems, or provide an independent scientific verification.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
POSITIVE = {'exact_copy', 'substantially_same_meaning'}
CATEGORIES = POSITIVE | {'merely_related', 'overlapping_information', 'uncertain', 'unrelated'}
GRID = [Fraction(i, 100) for i in range(50, 100)] + [Fraction(199, 200)]


def need(value, message):
    if not value:
        raise ValueError(message)


def read(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def rational(value):
    need(set(value) == {'numerator', 'denominator'}, 'fraction fields')
    n, d = value['numerator'], value['denominator']
    need(type(n) is int and type(d) is int and d > 0, 'fraction integer contract')
    result = Fraction(n, d)
    need(result.numerator == n and result.denominator == d, 'canonical fraction')
    return result


def integrity():
    manifest = read('MANIFEST.json')
    paths = [r['path'] for r in manifest['files']]
    need(len(paths) == len(set(paths)), 'duplicate manifest path')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    need(actual == set(paths) | {'MANIFEST.json'}, 'exact manifest file inventory')
    for entry in manifest['files']:
        path = ROOT / entry['path']
        need(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'unsafe member')
        raw = path.read_bytes()
        need(len(raw) == entry['bytes'], 'byte count: ' + entry['path'])
        need(hashlib.sha256(raw).hexdigest() == entry['sha256'], 'hash: ' + entry['path'])
        if path.suffix == '.py':
            ast.parse(raw.decode('utf-8'), filename=entry['path'])
    ledger = read('TRANSFORMATIONS.json')
    by_path = {x['path']: x for x in manifest['files']}
    for source in ledger['exact_unmodified_source_copies']:
        member = by_path[source['packaged_path']]
        need(source['original_sha256'] == member['sha256'] and source['bytes'] == member['bytes'], 'unmodified source binding')
    return len(paths)


def calibration(data):
    n, swaps = data['canonical_pairs'], data['swap_checks_per_model']
    need(data['calls_attempted'] == 2 * (n + swaps), 'call denominator')
    need(not data['selection_passed'] and data['selected_tau'] is None, 'negative terminal state')
    need(not data['fresh_validation_run'] and not data['semantic_validity_established'], 'unmet gates')
    need(data['model_retries'] == data['human_annotation_calls'] == 0, 'no retries or human annotations')
    for alias, model in data['models'].items():
        cats, status, all_status = (model[k] for k in ['canonical_category_counts', 'canonical_status_counts', 'all_call_status_counts'])
        need(set(cats) <= CATEGORIES and set(status) <= {'valid', 'invalid_json'}, 'known categories and statuses')
        need(all(type(v) is int and v >= 0 for v in list(cats.values()) + list(status.values()) + list(all_status.values())), 'nonnegative counts')
        need(sum(status.values()) == n and sum(cats.values()) == status.get('valid', 0), 'canonical margins')
        need(sum(all_status.values()) == n + swaps, 'all-call margin')
        need(all(all_status.get(k, 0) >= v for k, v in status.items()), 'canonical subset of calls')
        need(model['canonical_positive_count'] == sum(cats.get(c, 0) for c in POSITIVE), 'positive category count')
        swap = data['swap_diagnostics'][alias]
        need(swap['pairs'] == swaps, 'swap denominator')
        need(0 <= swap['binary_positive_changes'] <= swap['status_or_category_changes'] <= swaps, 'swap counts')
    requirement = rational(data['selection_requirement'])
    need(requirement == Fraction(19, 20), 'frozen required proportion')
    cuts = data['grid_ledger']
    need(len(cuts) == 51, '51 cuts required')
    last_support, last_den, last_num = n + 1, None, None
    for tau, row in zip(GRID, cuts):
        need(rational(row['tau']) == tau and row['tau_float_hex'] == float(tau).hex(), 'exact grid')
        den, num = rational(row['weighted_denominator']), rational(row['weighted_positive_numerator'])
        support = row['sample_support']
        need(type(support) is int and 0 <= support <= n and support <= last_support, 'nested support')
        need(0 <= num <= den and (support > 0) == (den > 0), 'weighted count contract')
        if last_den is not None:
            need(den <= last_den and num <= last_num, 'nested weighted totals')
        if den:
            precision = rational(row['conservative_precision'])
            upper = rational(row['missing_uncertain_sensitivity_upper'])
            need(precision == num / den, 'exact weighted quotient')
            need(precision <= upper <= 1, 'favorable sensitivity range')
            passed = precision >= requirement
        else:
            need(row['conservative_precision'] is None and row['missing_uncertain_sensitivity_upper'] is None, 'no-support semantics')
            passed = False
        need(row['passes_selection_rule'] is passed is False, 'frozen negative selection')
        last_support, last_den, last_num = support, den, num
    return cuts


def calibration_v4(data):
    # This cross-table contains counts only, not individual labels or IDs.
    cross = data['canonical_category_cross_counts']
    need(len({(r['qwen'], r['mistral']) for r in cross}) == len(cross), 'unique cross cells')
    need(sum(r['pairs'] for r in cross) == data['canonical_pairs'], 'cross count denominator')
    joint = both = disagreement = 0
    for alias in ('qwen', 'mistral'):
        margin = Counter()
        for row in cross:
            need(type(row['pairs']) is int and row['pairs'] > 0, 'cross count positivity')
            need(row[alias] in CATEGORIES | {'invalid_json'}, 'cross category')
            margin[row[alias]] += row['pairs']
        model = data['models'][alias]
        need({k: v for k, v in margin.items() if k in CATEGORIES} == model['canonical_category_counts'], 'cross-table category margin')
        need(margin['invalid_json'] == model['canonical_status_counts'].get('invalid_json', 0), 'cross-table invalid margin')
    for row in cross:
        joint += row['pairs'] * (row['qwen'] in POSITIVE and row['mistral'] in POSITIVE)
        valid = row['qwen'] in CATEGORIES and row['mistral'] in CATEGORIES
        both += row['pairs'] * valid
        disagreement += row['pairs'] * (valid and row['qwen'] != row['mistral'])
    need(joint == data['joint_positive_pairs'] == 27, 'joint positives')
    need(both == data['both_valid_pairs'] == 355, 'both valid')
    need(disagreement == data['valid_six_way_disagreements'] == 308, 'category disagreements')
    bins = data['nonempty_bins']
    need([r['bin'] for r in bins] == list(range(1, 13)), 'complete nonempty bins')
    need(sum(r['sample_pairs'] for r in bins) == data['canonical_pairs'], 'bin sample sum')
    need(sum(r['population_pairs'] for r in bins) == 220405510, 'population census sum')
    need(sum(r['joint_positives'] for r in bins) == joint, 'bin positive sum')
    for row in bins:
        need(row['sample_pairs'] == min(30, row['population_pairs']), 'frozen bin allocation')
        need(0 <= row['joint_positives'] <= row['sensitivity_possible_positives'] <= row['sample_pairs'], 'bin positive ranges')
    cuts = {rational(r['tau']): r for r in data['grid_ledger']}
    edges = [Fraction(1, 2)] + [Fraction(i, 100) for i in range(90, 100)] + [Fraction(199, 200)]
    for i, edge in enumerate(edges, 1):
        tail = [r for r in bins if r['bin'] >= i]
        den = sum((Fraction(r['population_pairs']) for r in tail), Fraction())
        num = sum((Fraction(r['population_pairs'], r['sample_pairs']) * r['joint_positives'] for r in tail), Fraction())
        upper_num = sum((Fraction(r['population_pairs'], r['sample_pairs']) * r['sensitivity_possible_positives'] for r in tail), Fraction())
        row = cuts[edge]
        need(row['sample_support'] == sum(r['sample_pairs'] for r in tail), 'boundary support')
        need(rational(row['weighted_denominator']) == den and rational(row['weighted_positive_numerator']) == num, 'boundary weighted sums')
        need(rational(row['missing_uncertain_sensitivity_upper']) == upper_num / den, 'boundary sensitivity')
    peak = max(rational(r['conservative_precision']) for r in data['grid_ledger'])
    upper_peak = max(rational(r['missing_uncertain_sensitivity_upper']) for r in data['grid_ledger'])
    need(peak == rational(data['maximum_weighted_joint_positive_proportion']) == Fraction(2, 5), 'maximum joint proportion')
    need(upper_peak == rational(data['maximum_missing_uncertain_sensitivity']) == Fraction(8, 15), 'maximum sensitivity')
    return len(edges)


def compute(data):
    rows = data['records']
    need([r['record'] for r in rows] == list(range(1, 73)), 'record enumeration')
    need(len(rows) == data['record_count'] == 72, '72 records')
    need(Counter(r['state'] for r in rows) == data['state_counts'] == {'COMPLETED': 68, 'FAILED': 4}, 'state counts')
    for group, summary in data['groups'].items():
        part = [r for r in rows if r['group'] == group]
        need(len(part) == summary['jobs'], 'group record count')
        need(sum(r['elapsed_seconds'] for r in part) == summary['elapsed_seconds_sum'], 'group duration sum')
    need(all(type(r['elapsed_seconds']) is int and r['elapsed_seconds'] >= 0 for r in rows), 'elapsed seconds')
    model = [r for r in rows if r['group'] == 'model_inference']
    embedding = [r for r in rows if r['group'] == 'embedding_array']
    need(sum(r['elapsed_seconds'] * r['gpu_count'] for r in model) == data['gpu_allocation_seconds'] == 25759, 'GPU allocation total')
    need(sum(r['elapsed_seconds'] for r in embedding) == data['embedding_elapsed_seconds'] == 479503, 'embedding duration')
    need(sum(r['elapsed_seconds'] * r['requested_cpus_per_task'] for r in embedding) == data['embedding_requested_cpu_seconds'] == 959006, 'requested CPU total')
    need(sum(r['elapsed_seconds'] for r in rows if r['state'] == 'FAILED') == 611, 'failure duration')
    need(not data['project_total_compute_complete'] and not data['energy_or_utilization_measured'], 'accounting limits')
    return len(rows)


def main():
    files = integrity()
    v3, v4 = read('data/calibration_v3.json'), read('data/calibration_v4.json')
    calibration(v3); calibration(v4)
    need(v3['joint_positive_pairs'] == 0 and v3['models']['qwen']['canonical_positive_count'] == 0, 'v3 zero-joint result')
    boundary_cuts = calibration_v4(v4)
    records = compute(read('data/compute_history.json'))
    table = []
    for data in (v3, v4):
        table.append({'version':data['version'],'canonical_pairs':data['canonical_pairs'],
                      'model_calls':data['calls_attempted'],'joint_positives':data['joint_positive_pairs'],
                      'failed_cuts':len(data['grid_ledger']),'threshold_selected':False,
                      'fresh_validation':False})
    print(json.dumps({'passed':True,'scope':'aggregate arithmetic and manifest replay only',
                      'payload_files':files,'cut_quotients_and_decisions_checked':102,
                      'v4_bin_boundary_cuts_reconstructed':boundary_cuts,'compute_records_summed':records,
                      'calibration_table':table,
                      'not_replayed':['private pair scores or individual labels','fresh model inference',
                                     'within-bin sample selection','natural effect experiments','universal theorem proofs'],
                      'new_independent_scientific_verification':False},indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
