"""Public import support: only the original require function is retained.

This is an excerpt, not the original deployment common.py. Operational paths
and publication/activation helpers are intentionally absent. See ADDON_SOURCE_MAP.
"""
def require(value, message):
    if not value:
        raise ValueError(message)

