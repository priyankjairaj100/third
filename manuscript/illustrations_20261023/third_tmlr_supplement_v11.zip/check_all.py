#!/usr/bin/env python3
"""Read-only current supplement replay, using the Python standard library."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def need(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    def bad(value):
        raise ValueError('Non-finite JSON: ' + value)
    return json.loads(path.read_bytes(), object_pairs_hook=pairs, parse_constant=bad)

def binding(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def main():
    need(sys.version_info >= (3, 10), 'Python 3.10+ is required')
    need(not sys.flags.optimize, 'Run without -O')
    sys.dont_write_bytecode = True
    need(not any(p.is_symlink() for p in ROOT.rglob('*')), 'No symlinks')
    manifest = read(ROOT / 'MANIFEST.json')
    need(manifest['schema'] == 'third-flat-anonymous-supplement-v1', 'Schema')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    need(actual == set(manifest['files']) | {'MANIFEST.json'}, 'Exact inventory')
    syntax_count = 0
    for name, expected in manifest['files'].items():
        p = PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts and '\\' not in name, 'Safe path')
        need(binding(ROOT / name) == expected, 'Hash/size mismatch: ' + name)
        if name.endswith('.py'):
            ast.parse((ROOT / name).read_bytes(), filename=name)
            syntax_count += 1
    sources = read(ROOT / 'SOURCE_MAP.json')
    for name, item in sources['unchanged_copies'].items():
        need(binding(ROOT / name) == item['binding'], 'Exact original source binding')
    for name, item in sources.get('derived_entries', {}).items():
        need(binding(ROOT / name) == item['binding'], 'Derived packaging binding')
    need(binding(ROOT / 'manuscript.tex') == sources['current_manuscript'], 'Current source')
    need(sources['scientific_results_changed'] is False, 'Result preservation')
    structure_bindings = read(ROOT / 'evidence/structure/SOURCE_BINDINGS.json')
    repair_bindings = read(ROOT / 'evidence/repair/SOURCE_BINDINGS.json')
    need(binding(ROOT / 'code/stage1/structure_stage1.py') ==
         structure_bindings['executed_package_members']['structure_stage1.py'], 'Structure generator')
    need(binding(ROOT / 'code/stage2/curation_repair.py') ==
         repair_bindings['executed_package_members']['curation_repair.py'], 'Repair generator')
    need(binding(ROOT / 'code/stage2/stage1_common.py') ==
         repair_bindings['helper_binding'], 'Repair helper')
    for bundle in (structure_bindings, repair_bindings):
        for name, expected in bundle['frozen_research_sources'].items():
            need(binding(ROOT / 'code' / name) == expected, 'Frozen source: ' + name)
    spec = importlib.util.spec_from_file_location('calibration_aggregate_checks', ROOT / 'checks/calibration.py')
    cal = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cal)
    cal.ROOT = ROOT / 'evidence/calibration'
    v3 = cal.read('data/calibration_v3.json')
    v4 = cal.read('data/calibration_v4.json')
    cal.calibration(v3)
    cal.calibration(v4)
    cal.need(v3['joint_positive_pairs'] == 0 and v3['models']['qwen']['canonical_positive_count'] == 0,
             'v3 zero-joint result')
    boundaries = cal.calibration_v4(v4)
    compute_records = cal.compute(cal.read('data/compute_history.json'))
    stages = {}
    for label in ('structure', 'repair'):
        directory = ROOT / 'evidence' / label
        p = subprocess.run([sys.executable, '-B', str(directory / 'replay_aggregates.py')],
                           cwd=directory, capture_output=True, text=True, timeout=120)
        need(p.returncode == 0, label + ' replay failed: ' + p.stderr)
        stages[label] = json.loads(p.stdout)
        need(stages[label]['passed'] is True, label + ' replay')
    protocol = read(ROOT / 'annotation/protocol_view.json')
    need(protocol['executed_document'] is False and protocol['private_examples_included'] is False,
         'Public protocol view scope')
    for name, expected in protocol['exact_prompt_and_schema_files'].items():
        need(binding(ROOT / 'annotation' / name) == expected, 'Prompt/schema binding')
    need(protocol['v3']['model_labels'] == protocol['v4']['inherited']['model_labels'], 'Same label rule')
    need(protocol['v4']['selection']['precision_min'] == '19/20', 'Frozen selection gate')
    need(stages['structure']['summary']['threshold_selected'] is False, 'No structural threshold')
    need(stages['repair']['summary']['human_or_model_annotations'] == 0, 'No added annotation')
    print(json.dumps({
        'passed': True,
        'payload_files_checked': len(manifest['files']),
        'python_sources_syntax_checked': syntax_count,
        'unchanged_copy_bindings_checked': len(sources['unchanged_copies']),
        'manuscript_source_sha256': sources['current_manuscript']['sha256'],
        'calibration': {'cut_quotients_and_decisions_checked': 102,
                        'v4_bin_boundaries_reconstructed': boundaries,
                        'compute_records_summed': compute_records,
                        'v3_and_v4_selection_passed': False,
                        'fresh_validation_run': False},
        'structure': stages['structure'], 'repair': stages['repair'],
        'generating_code_executed': False,
        'private_data_replayed': False,
        'scope': 'File identity, source syntax and aggregate arithmetic; no private inference, graph/state regeneration or proof verification.'
    }, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
