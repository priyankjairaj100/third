#!/usr/bin/env python3
"""Check exact inventory and aggregate receipts; Python 3.10+ standard library.

Generating code is syntax parsed, never imported or executed. Saved equality
receipts are not a fresh replay of private graphs or states.
"""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import re
import stat
import subprocess
import sys
import tempfile
import zipfile


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    def constant(value):
        raise ValueError("Non-finite JSON value: " + value)
    return json.loads(path.read_bytes(), object_pairs_hook=pairs, parse_constant=constant)


def binding(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def safe_name(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name


def replay(script, cwd):
    result = subprocess.run([sys.executable, "-B", str(script)], cwd=cwd,
                            capture_output=True, text=True, timeout=120)
    require(result.returncode == 0, "Replay failed: " + result.stderr)
    receipt = json.loads(result.stdout)
    require(receipt.get("passed") is True, "Replay did not pass")
    return receipt


def main():
    require(sys.version_info >= (3, 10), "Python 3.10 or newer is required")
    require(not sys.flags.optimize, "Run without -O: nested checkers use assertions")
    root = Path(__file__).resolve().parent
    manifest = read(root / "MANIFEST.json")
    require(manifest["schema"] == "anonymous-supplement-inventory-v4", "Wrong inventory schema")
    require(not any(p.is_symlink() for p in root.rglob("*")), "Symbolic links are not permitted")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(actual == set(manifest["files"]) | {"MANIFEST.json"}, "Unexpected or missing file")
    for name, expected in manifest["files"].items():
        require(safe_name(name), "Unsafe inventory name")
        require(binding(root / name) == expected, "Hash or size mismatch: " + name)
    sources = read(root / "BINDINGS.json")
    require(sources["schema"] == "anonymous-supplement-source-bindings-v4", "Wrong binding schema")
    require(sources["scope"] == "historical_calibration_and_completed_development_stages1_2", "Wrong scope")
    require(re.fullmatch(r"[0-9a-f]{64}", sources["manuscript_source_sha256"]) is not None, "Invalid manuscript hash")
    require(sources["original_semantic_gate_passed"] is False, "Original gate must remain failed")
    require(sources["new_human_annotation_or_review"] is False, "No human annotation added")
    require(sources["historical_reviews_rebound"] is False, "Old reviews must keep their old bindings")
    previous = root / "previous" / "tmlr_anonymous_supplement_v3.zip"
    require(binding(previous) == sources["previous_anonymous_supplement"], "V3 archive mismatch")
    require(binding(root / "repair" / "MANIFEST.json") == sources["repair_manifest"], "Stage 2 manifest mismatch")
    stage = read(root / "repair" / "SOURCE_BINDINGS.json")
    code = sources["generating_code"]
    expected_code = {
        "code/stage2/curation_repair.py": stage["executed_package_members"]["curation_repair.py"],
        "code/stage2/stage1_common.py": stage["helper_binding"],
        **{"code/" + name: b for name, b in stage["frozen_research_sources"].items()},
    }
    require(stage["helper_binding"] == stage["executed_package_members"]["stage1_common.py"], "Helper binding mismatch")
    require(set(code) == set(expected_code) and len(code) == 8, "Stage 2 generating-source inventory mismatch")
    for name, expected in expected_code.items():
        require(safe_name(name), "Unsafe code name")
        require(code[name]["binding"] == expected == binding(root / name), "Generating-source mismatch")
        ast.parse((root / name).read_text(), filename=name)
    repair_receipt = replay(root / "repair" / "replay_aggregates.py", root / "repair")
    with tempfile.TemporaryDirectory(prefix="anonymous-supplement-v3-replay-") as directory:
        extracted = Path(directory)
        with zipfile.ZipFile(previous) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)), "Duplicate previous archive member")
            require(archive.testzip() is None, "Previous archive CRC failure")
            for member in archive.infolist():
                require(safe_name(member.filename), "Unsafe previous archive name")
                require(not stat.S_ISLNK(member.external_attr >> 16), "Previous archive symlink")
            archive.extractall(extracted)
        previous_receipt = replay(extracted / "check_all.py", extracted)
    require(previous_receipt["original_semantic_gate_passed"] is False, "Prior gate result changed")
    print(json.dumps({
        "passed": True,
        "payload_files_checked": len(manifest["files"]),
        "generating_source_files_syntax_checked": len(code),
        "generating_code_executed": False,
        "manuscript_source_sha256": sources["manuscript_source_sha256"],
        "previous_supplement": previous_receipt,
        "repair_stage2": repair_receipt,
        "original_semantic_gate_passed": False,
        "scope": "Integrity, source syntax and saved aggregate arithmetic only; no private graph or state regeneration.",
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
