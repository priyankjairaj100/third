ANONYMOUS SUPPLEMENT, VERSION 4

Scope and retained boundaries
-----------------------------
This version accompanies the exact manuscript source hash in BINDINGS.json.
It adds completed Stage 2 natural-development membership repair evidence to
the unchanged V3 supplement, which contains Stage 1 structural evidence and
the historical negative-calibration supplement. The manuscript is not included.
All older source bindings and reviews remain historical and unchanged.

Both original LLM calibrations failed. No semantic threshold was selected and
no fresh semantic validation was admitted. Stage 2 is a separately declared
post-failure correctness study on the same fixed 1,001-row development-training
panel, over all 51 fixed cutoffs. It preserves all prior negative results,
held-out boundaries and unmet semantic/human gates. Future annotation is fully
LLM with zero human pair review. Stages 1 and 2 use no task labels or annotation.

Stage 2 completed 102 arms (one R and one S trajectory per cutoff), 13,056
singleton membership checks, and 408 checkpoints. These are execution receipts
and bounded development correctness cases, not a semantic-quality, task-utility,
deployment-prevalence, physical-erasure, kernel-isolation or efficiency result.
R and S delete different record volumes and are not matched-volume comparisons.
The retained field fresh_retained_graph_equal means fresh retained-data selected
membership and canonical logical-state equality. It does not assert direct
edge-array equality or serialized-byte equality. See the bound interpretation.

Portable aggregate replay
-------------------------
Extract into a new empty directory. From any working directory run:

    python3 -B /path/to/extracted/check_all.py

Python 3.10 or newer, without -O, is required. Only the standard library is
used; no network or private inputs are needed. Save receipts outside the
extracted directory because inventory checks reject added files. The checker
checks all outer hashes, parses the eight Stage 2 research-source files without
executing them, runs repair/replay_aggregates.py, and temporarily extracts V3
to run its unchanged checker (including Stage 1 and historical calibration).
Temporary extraction is removed automatically. Hash inventories establish byte
integrity, not external authenticity. Saved equality flags remain receipts;
this replay cannot reconstruct private graphs, requests, states or LLM outputs.

Code inspection and scientific rerun limits
------------------------------------------
code/stage2/curation_repair.py and stage1_common.py are exact executed sources.
code/ contains the six exact frozen research dependencies in their original
relative repository layout. Hashes are checked against the executed package
and protocol bindings in repair/SOURCE_BINDINGS.json. Syntax parsing does not
validate scientific behavior. No numerical source is imported by check_all.py.

A fresh scientific run requires the original private input artifacts and
executed protocol, pinned Linux/Python/NumPy/SciPy runtime, and original resource
admission. Those requirements are not supplied or authorized by this package.
The deidentified protocol view is not an executable substitute for the original.
The standard-library aggregate replay remains distinct from a scientific rerun.

Contents
--------
previous/tmlr_anonymous_supplement_v3.zip: exact unchanged V3 archive.
repair/: complete unchanged 68-file public Stage 2 bundle, including all 54
run records, initial and corrected audit receipts, interpretation, full-cut
summaries, deidentified protocol/resources, source bindings and its manifest.
code/: exact Stage 2 generator, helper and six frozen dependencies.
BINDINGS.json, PRIVACY.json, MANIFEST.json, check_all.py: new version wrapper.

Privacy and provenance
----------------------
No operational launch/scheduler wrappers, actual host/account/job identifiers,
private filesystem paths, corpus text, record/source IDs, task labels, vectors,
membership/state payloads, raw logs, weights or repository history are included.
The source ledgers retain filenames and hashes of omitted operational artifacts
for provenance; their bytes are absent. Exact code, input hashes and request
digests can remain linkable to public sources or known artifacts, so this is
metadata removal and bounded content review, not an unlinkability guarantee.
The unchanged nested V3 has its original Stage 1-only scope and older manuscript
hash. Its statements are historical, not a contradiction or a reissued review.
